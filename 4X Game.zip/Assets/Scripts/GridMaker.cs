using UnityEngine;
using System.Collections;
using System.Collections.Generic;






public class GridMaker : MonoBehaviour
{
    [SerializeField] private int _width, _height;

    [SerializeField] private Tile _tilePrefab;

    [SerializeField] private Transform _cam;    
    
    [SerializeField] private Object _buildingPrefab;

    [SerializeField] private int _buildingTileX, _buildingTileY;

    public List<string> _buildingTiles;

    private Animator _animator;

    [SerializeField] private int _numPoints;

    private List<Vector2> _points;

    private List<int> _tiles;




    void Start () {
        GenerateGrid();
    }



    void GenerateGrid() {
        makeMap();
        var loopCounter = 0;
        for (int x = 0; x < _width; x++) {
            for (int y = 0; y < _height; y++) {
                var spawnedTile = Instantiate(_tilePrefab, new Vector2(x, y), Quaternion.identity);
                _animator = spawnedTile.GetComponent<Animator>();
                spawnedTile.name = $"Tile {x} {y}";
                _animator.SetInteger("AnimState", _tiles[loopCounter]);
                if (x == _buildingTileX && y == _buildingTileY) {
                    var spawnedBuilding = Instantiate(_buildingPrefab, new Vector3(x, y, -5), Quaternion.identity);
                    spawnedBuilding.name = $"Building {x} {y}";
                }
            loopCounter += 1;
            }
        }


        _cam.transform.position = new Vector3((float) _width/2 -0.5f, (float) _height/2 -0.5f, -10);
    }

    void makeMap() {
        for (int i = 0; i < _numPoints; i++) {

            var addedPoint = new Vector2(Random.Range(0, _width), Random.Range(0, _height));
            Debug.Log(addedPoint);
            _points.Add(addedPoint);

        }
        for (int x = 0; x < _width; x++) {

            for (int y = 0; y < _height; y++) {

                var newTile = new Vector2(x, y);

                var closestPoint = 0;

                for (int i = 0; i < _points.Count; i++) {

                    if (Vector2.Distance(newTile, _points[i]) < Vector2.Distance(newTile, _points[closestPoint])) {

                        closestPoint = i;

                    }
                }
                _tiles.Add(closestPoint);

            }
        }
    }
}
