using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class MapMaker : MonoBehaviour
{
    [SerializeField] private int _width, _height;

    [SerializeField] private int _numPoints;

    private List<int> _points;



    void makeMap() {
        for (int i = 0; i < _numPoints; i++) {
            _points[i] = Random.Range(0, _width), Random.Range(0, _height);
        }
    }
}
