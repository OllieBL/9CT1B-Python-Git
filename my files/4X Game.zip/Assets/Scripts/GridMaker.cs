using UnityEngine;

public class GridMaker : MonoBehaviour
{
    [SerializeField] private int _width, _height;

    [SerializeField] private Tile _tilePrefab;

    [SerializeField] private Transform _cam;    
    
    [SerializeField] private Object _buildingPrefab;

    [SerializeField] private int _buildingTileX, _buildingTileY;

    [SerializeField] private Animator _animator;




    void Start () {
        GenerateGrid();
    }



    void GenerateGrid() {
        for (int x = 0; x < _width; x++) {
            for (int y = 0; y < _height; y++) {
                var spawnedTile = Instantiate(_tilePrefab, new Vector2(x, y), Quaternion.identity);
                spawnedTile.name = $"Tile {x} {y}";
                if (x == _buildingTileX && y == _buildingTileY) {
                    var spawnedBuilding = Instantiate(_buildingPrefab, new Vector3(x, y, -5), Quaternion.identity);
                    spawnedBuilding.name = $"Building {x} {y}";
                }
            }
        }


        _cam.transform.position = new Vector3((float) _width/2 -0.5f, (float) _height/2 -0.5f, -10);
    }
}
