using UnityEngine;

public class Tile : MonoBehaviour
{
    [SerializeField] private Color _baseColour;
    [SerializeField] private SpriteRenderer _renderer;
}
