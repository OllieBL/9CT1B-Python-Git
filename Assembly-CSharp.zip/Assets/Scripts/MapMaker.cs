using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class MapMaker : MonoBehaviour
{
    [SerializeField] private int _width, _height;

    [SerializeField] private int _numPoints;

    private List<Vector2> _points;

    public List<Vector2> _tiles;



    void makeMap() {
        for (int i = 0; i < _numPoints; i++) {
            var addedPoint = new Vector2(Random.Range(0, _width), Random.Range(0, _height));
            _points.Add(addedPoint);
        }
        for (int x = 0; x < _width; x++) {
            for (int y = 0; y < _height; y++) {
                var newTile = new Vector2(x, y);
                _tiles.Add(newTile);

                var closestPoint = 0;

                for (int i = 0; i < _points.Count; i++) {
                    if (Vector2.Distance(newTile, _points[i]))
                }
            }
        }
    }
}
